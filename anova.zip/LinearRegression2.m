
close all
clearvars
clc

%% Load data
load Frs.mat

x = indepVar;
y = depVar;
n=numel(x(:,1));
p=6;

A=[ones(n,1) x x(:,1).*x(:,2) x(:,1).*x(:,3) x(:,2).*x(:,3)];
theta_hat = A\y;

err = y-A*theta_hat;
sse = err'*err;
sst = (y-mean(y))'*(y-mean(y));

thegma_eps_2 = sse/(n-p);

numvar = length(theta_hat);

t=zeros(numvar,1);
theta_hat_low=zeros(numvar,1);
theta_hat_up=zeros(numvar,1);
alpha=0.1;
disp(['For confidence bound of',num2str(1-alpha)]);
for i =1:numvar
    AA=A'*A;
    t(i)=abs(tinv(alpha/2,n-p))*(thegma_eps_2*AA(i,i))^0.5;
    theta_hat_low(i) = theta_hat(i) - t(i);
    theta_hat_up(i) = theta_hat(i) + t(i);
    disp([' [', num2str(theta_hat_low(i)),' , ',']    ',num2str(theta_hat_up(i))])
end
alpha=0.05;
disp(['For confidence bound of ',num2str(1-alpha)]);
for i =1:numvar
    AA=A'*A;
    t(i)=abs(tinv(alpha/2,n-p))*(thegma_eps_2*AA(i,i))^0.5;
    theta_hat_low(i) = theta_hat(i) - t(i);
    theta_hat_up(i) = theta_hat(i) + t(i);
    disp([' [', num2str(theta_hat_low(i)),' , ',num2str(theta_hat_up(i)),num2str(theta_hat(i)),']  ',num2str(theta_hat(i))])
end
alpha=0.01;

disp('')
disp(['For confidence bound of ',num2str(1-alpha)]);
for i =1:numvar
    AA=A'*A;
    t(i)=abs(tinv(alpha/2,n-p))*(thegma_eps_2*AA(i,i))^0.5;
    theta_hat_low(i) = theta_hat(i) - t(i);
    theta_hat_up(i) = theta_hat(i) + t(i);
    disp([' [', num2str(theta_hat_low(i)),' , ',num2str(theta_hat_up(i)),']  ',num2str(theta_hat(i))])
end

R_square = 1-sse/sst;

disp(['R_square=',num2str(R_square)]);


