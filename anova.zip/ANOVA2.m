
close all
clearvars
clc

%% Load data
load Frs.mat

%% Run ANOVA function of MATLAB
anovan(depVar, indepVar, 'model', 'interaction')

x2=indepVar(:,2);
x3=indepVar(:,3);
X2=reshape(x2(1:25),5,[]);
X3=reshape(x3(1:25),5,[]);

Z=reshape((depVar(1:25)+depVar(26:50)+depVar(51:75)...
    +depVar(76:100)+depVar(101:125))/5,5,[]);
surf(X2, X3, Z)

xlabel('x2')
ylabel('x3')
zlabel('F(x2, x3)')









